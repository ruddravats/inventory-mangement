# StockSphere 5-Year Realistic Dataset

Period: 2022-01-01 through 2026-08-27 (1,700 calendar days)

This is a coherent synthetic business dataset designed for the StockSphere PBL application. Numbers are generated from demand patterns and business rules rather than random dashboard values.

## Included
- 16 products across 6 categories
- 6 suppliers
- 3 warehouses and 24 bins
- 22,000 customer orders and 22,000 order lines
- 27,200 product-day sales records
- 896 purchase orders
- 896 receipts
- 574 customer returns
- 14,015 inventory transactions
- 12 batches
- 32 serial numbers
- 18 stocktakes
- 150 operational requests

## Business logic
Revenue = sum(order line quantity × selling price)
COGS = sum(order line quantity × unit cost)
Gross Profit = Revenue − COGS
Available = On Hand − Reserved − QC Hold − Damaged
Every inventory transaction satisfies BEFORE + DELTA = AFTER.
Product on-hand reconciles with warehouse location balances and final transaction balances.

## 5-year use
The daily sales history can be used for moving averages, standard deviation, trend analysis, linear-regression forecasting, ABC analysis, dead-stock analysis, and stockout-risk calculations.

Demo password for all four users: demo123
